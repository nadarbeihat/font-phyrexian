package com.phyrexian.keyboard

import android.graphics.Color
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class PhyrexianIME : InputMethodService(), PhyrexianKeyboardView.Listener {

    private lateinit var previewText: TextView
    private lateinit var keyboardView: PhyrexianKeyboardView
    private val composing = StringBuilder()

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(Color.parseColor("#12100E"))
        }

        val typeface = Typeface.createFromAsset(assets, "fonts/PhyrexiaNeue-Transliteration.otf")

        // Preview strip: shows the word you're currently typing, rendered big,
        // fully in the Phyrexian glyphs.
        val previewBar = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (56 * resources.displayMetrics.density).toInt()
            )
            setBackgroundColor(Color.parseColor("#1B1512"))
        }
        previewText = TextView(this).apply {
            typeface = typeface
            textSize = 22f
            setTextColor(Color.parseColor("#C9A86A"))
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setPadding(24, 0, 24, 0)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        previewBar.addView(previewText)
        root.addView(previewBar)

        keyboardView = PhyrexianKeyboardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (220 * resources.displayMetrics.density).toInt()
            )
            listener = this@PhyrexianIME
        }
        root.addView(keyboardView)

        return root
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        composing.clear()
        updatePreview()
    }

    private fun updatePreview() {
        previewText.text = if (composing.isEmpty()) "…" else composing.toString()
    }

    override fun onChar(c: Char) {
        currentInputConnection?.commitText(c.toString(), 1)
        if (c == ' ') composing.clear() else composing.append(c)
        updatePreview()
    }

    override fun onDelete() {
        currentInputConnection?.deleteSurroundingText(1, 0)
        if (composing.isNotEmpty()) composing.deleteCharAt(composing.length - 1)
        updatePreview()
    }

    override fun onSpace() {
        currentInputConnection?.commitText(" ", 1)
        composing.clear()
        updatePreview()
    }

    override fun onEnter() {
        currentInputConnection?.commitText("\n", 1)
        composing.clear()
        updatePreview()
    }

    override fun onShiftToggled(shift: Boolean) {
        // no-op, view redraws itself
    }
}
