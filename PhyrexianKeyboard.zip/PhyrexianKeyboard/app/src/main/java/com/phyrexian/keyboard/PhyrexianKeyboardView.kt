package com.phyrexian.keyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * A hand-rolled keyboard view. Every key cap is drawn using the Phyrexian
 * transliteration font, so the layout LOOKS Phyrexian while every key still
 * produces a normal ASCII character underneath (that's what makes the text
 * work in any app you paste it into).
 */
class PhyrexianKeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onChar(c: Char)
        fun onDelete()
        fun onSpace()
        fun onEnter()
        fun onShiftToggled(shift: Boolean)
    }

    var listener: Listener? = null
    var shiftOn: Boolean = false
        private set

    private val phyrexianTypeface: Typeface =
        Typeface.createFromAsset(context.assets, "fonts/PhyrexiaNeue-Transliteration.otf")

    private val rows = listOf(
        "qwertyuiop".toList(),
        "asdfghjkl".toList(),
        listOf('\u21E7') + "zxcvbnm".toList() + listOf('\u232B'), // shift ... backspace
        listOf(',', ' ', '.', '\u23CE') // comma, space(wide), period, enter
    )

    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2A211A")
        style = Paint.Style.FILL
    }
    private val keyPaintSpecial = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#5B0A0A")
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C9A86A")
        textAlign = Paint.Align.CENTER
        typeface = phyrexianTypeface
    }
    private val plainLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#C9A86A")
        textAlign = Paint.Align.CENTER
    }

    // computed per-key hit boxes, rebuilt on layout
    private data class KeySlot(val rect: RectF, val char: Char, val wide: Boolean = false)
    private val slots = mutableListOf<KeySlot>()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutKeys(w.toFloat(), h.toFloat())
    }

    private fun layoutKeys(w: Float, h: Float) {
        slots.clear()
        val rowH = h / rows.size
        for ((r, row) in rows.withIndex()) {
            val top = r * rowH
            val bottom = top + rowH
            if (r == 3) {
                // bottom row: , [space wide] . enter
                val commaW = w * 0.15f
                val enterW = w * 0.20f
                val periodW = w * 0.15f
                val spaceW = w - commaW - enterW - periodW
                var x = 0f
                slots.add(KeySlot(RectF(x, top, x + commaW, bottom), ','))
                x += commaW
                slots.add(KeySlot(RectF(x, top, x + spaceW, bottom), ' ', wide = true))
                x += spaceW
                slots.add(KeySlot(RectF(x, top, x + periodW, bottom), '.'))
                x += periodW
                slots.add(KeySlot(RectF(x, top, x + enterW, bottom), '\n'))
            } else {
                val keyW = w / row.size
                for ((i, c) in row.withIndex()) {
                    val left = i * keyW
                    slots.add(KeySlot(RectF(left, top, left + keyW, bottom), c))
                }
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val pad = 6f
        labelPaint.textSize = height / rows.size * 0.5f
        plainLabelPaint.textSize = height / rows.size * 0.35f
        for (slot in slots) {
            val special = slot.char == '\u21E7' || slot.char == '\u232B' || slot.char == '\n'
            val r = RectF(slot.rect.left + pad, slot.rect.top + pad, slot.rect.right - pad, slot.rect.bottom - pad)
            canvas.drawRoundRect(r, 10f, 10f, if (special) keyPaintSpecial else keyPaint)

            val cy = r.centerY() - (labelPaint.descent() + labelPaint.ascent()) / 2
            when (slot.char) {
                '\u21E7' -> { // shift glyph, drawn plain (arrow), highlight if on
                    plainLabelPaint.color = if (shiftOn) Color.parseColor("#FFFFFF") else Color.parseColor("#C9A86A")
                    canvas.drawText("\u21E7", r.centerX(), r.centerY() - (plainLabelPaint.descent() + plainLabelPaint.ascent()) / 2, plainLabelPaint)
                }
                '\u232B' -> canvas.drawText("\u232B", r.centerX(), r.centerY() - (plainLabelPaint.descent() + plainLabelPaint.ascent()) / 2, plainLabelPaint)
                '\n' -> canvas.drawText("\u23CE", r.centerX(), r.centerY() - (plainLabelPaint.descent() + plainLabelPaint.ascent()) / 2, plainLabelPaint)
                ' ' -> canvas.drawText("space", r.centerX(), r.centerY() - (plainLabelPaint.descent() + plainLabelPaint.ascent()) / 2, plainLabelPaint)
                else -> {
                    val display = if (shiftOn) slot.char.uppercaseChar() else slot.char
                    canvas.drawText(display.toString(), r.centerX(), cy, labelPaint)
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val slot = slots.firstOrNull { it.rect.contains(event.x, event.y) } ?: return true
        performClick()
        when (slot.char) {
            '\u21E7' -> {
                shiftOn = !shiftOn
                listener?.onShiftToggled(shiftOn)
                invalidate()
            }
            '\u232B' -> listener?.onDelete()
            '\n' -> listener?.onEnter()
            ' ' -> listener?.onSpace()
            else -> {
                val c = if (shiftOn) slot.char.uppercaseChar() else slot.char
                listener?.onChar(c)
                if (shiftOn) {
                    shiftOn = false
                    listener?.onShiftToggled(false)
                    invalidate()
                }
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
